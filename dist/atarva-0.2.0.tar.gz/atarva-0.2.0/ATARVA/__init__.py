#! /usr/bin/env python
from ATARVA.version import __version__
